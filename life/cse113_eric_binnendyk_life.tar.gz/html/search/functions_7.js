var searchData=
[
  ['read_5ffile',['read_file',['../life_8c.html#a6549f4c230630e60ed521498465213b5',1,'read_file(FILE *patfile, unsigned char **life_grid, int width, int height, struct point_t offset, int mode):&#160;life.c'],['../life_8h.html#a6549f4c230630e60ed521498465213b5',1,'read_file(FILE *patfile, unsigned char **life_grid, int width, int height, struct point_t offset, int mode):&#160;life.c']]]
];
