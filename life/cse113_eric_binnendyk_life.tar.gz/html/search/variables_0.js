var searchData=
[
  ['blue',['blue',['../structcolor__t.html#ae7b396dd4ef019a28101fffe17ac33af',1,'color_t']]]
];
