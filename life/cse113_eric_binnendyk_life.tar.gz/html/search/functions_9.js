var searchData=
[
  ['update_5fcell',['update_cell',['../life_8c.html#ac2affa355c9fada2f5425e42bfc8a253',1,'update_cell(unsigned char **next_gen, unsigned char **life_grid, int x, int y, int width, int height, struct point_t *all_neighbors):&#160;life.c'],['../life_8h.html#ac2affa355c9fada2f5425e42bfc8a253',1,'update_cell(unsigned char **next_gen, unsigned char **life_grid, int x, int y, int width, int height, struct point_t *all_neighbors):&#160;life.c']]]
];
