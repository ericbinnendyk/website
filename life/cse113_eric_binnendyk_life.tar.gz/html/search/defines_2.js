var searchData=
[
  ['klein',['KLEIN',['../life_8h.html#a5dacc98c82a42c9d28e03ab2234c1bb8',1,'life.h']]]
];
