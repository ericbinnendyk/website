var searchData=
[
  ['width',['width',['../structsdl__info__t.html#a347a3ae7f67b70ba5542d434f7d4dc8b',1,'sdl_info_t']]],
  ['window',['window',['../structsdl__info__t.html#ae06510785e8d9ca03a6371aef2b908fa',1,'sdl_info_t']]]
];
