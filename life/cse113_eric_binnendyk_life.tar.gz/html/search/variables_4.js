var searchData=
[
  ['red',['red',['../structcolor__t.html#ac498f95c1c5217d2033d5bbcb689f0c3',1,'color_t']]],
  ['renderer',['renderer',['../structsdl__info__t.html#a76af8f5f73014164c54775b91d6a66ce',1,'sdl_info_t']]]
];
