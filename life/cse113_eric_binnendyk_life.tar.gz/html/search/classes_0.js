var searchData=
[
  ['color_5ft',['color_t',['../structcolor__t.html',1,'']]]
];
