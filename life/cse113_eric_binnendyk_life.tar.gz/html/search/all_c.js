var searchData=
[
  ['read_5ffile',['read_file',['../life_8c.html#a6549f4c230630e60ed521498465213b5',1,'read_file(FILE *patfile, unsigned char **life_grid, int width, int height, struct point_t offset, int mode):&#160;life.c'],['../life_8h.html#a6549f4c230630e60ed521498465213b5',1,'read_file(FILE *patfile, unsigned char **life_grid, int width, int height, struct point_t offset, int mode):&#160;life.c']]],
  ['red',['red',['../structcolor__t.html#ac498f95c1c5217d2033d5bbcb689f0c3',1,'color_t']]],
  ['renderer',['renderer',['../structsdl__info__t.html#a76af8f5f73014164c54775b91d6a66ce',1,'sdl_info_t']]]
];
