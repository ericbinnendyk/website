var searchData=
[
  ['parse_5ffile_5f105',['parse_file_105',['../life_8c.html#af317025664832b9f69d96b45af7c869b',1,'parse_file_105(FILE *patfile, unsigned char **patt_grid, int width, int height, struct point_t offset, int mode):&#160;life.c'],['../life_8h.html#adfb6bccbb285fae3bdf348cb450ecf50',1,'parse_file_105(FILE *patfile, unsigned char **life_grid, int width, int height, struct point_t offset, int mode):&#160;life.c']]],
  ['parse_5ffile_5f106',['parse_file_106',['../life_8c.html#acef858fe83d825e1b0bb3a0f62e09f21',1,'parse_file_106(FILE *patfile, unsigned char **patt_grid, int width, int height, struct point_t offset, int mode):&#160;life.c'],['../life_8h.html#a618adaa4485f227c9690206afb6bf40e',1,'parse_file_106(FILE *patfile, unsigned char **life_grid, int width, int height, struct point_t offset, int mode):&#160;life.c']]],
  ['point_5ft',['point_t',['../structpoint__t.html',1,'']]],
  ['print_5fgen',['print_gen',['../gl_8c.html#aa7b62839c4fd2a6a7c0d3519854fa4fb',1,'gl.c']]],
  ['print_5fhelp',['print_help',['../gl_8c.html#ad523dc0948afa347666bc671d56f9a40',1,'gl.c']]]
];
