var searchData=
[
  ['out_5fof_5fbounds',['out_of_bounds',['../life_8c.html#a23dd050b78146a55e79b1bf22352eabe',1,'out_of_bounds(struct point_t cell, int width, int height):&#160;life.c'],['../life_8h.html#a23dd050b78146a55e79b1bf22352eabe',1,'out_of_bounds(struct point_t cell, int width, int height):&#160;life.c']]]
];
