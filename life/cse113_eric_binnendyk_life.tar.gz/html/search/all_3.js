var searchData=
[
  ['find_5fneighbors',['find_neighbors',['../life_8c.html#acceb2661e76d1bca287f3c4a98228008',1,'find_neighbors(int x, int y, int width, int height, int mode, struct point_t *neighbor_coords):&#160;life.c'],['../life_8h.html#a5680d439790ff3188f7c64711bfe37e2',1,'find_neighbors(int i, int j, int width, int height, int mode, struct point_t *neighbor_coords):&#160;life.c']]],
  ['free_5fall',['free_all',['../gl_8c.html#a36fb4d751a4f3a338c6f0cf6538b6ff8',1,'gl.c']]],
  ['free_5fgrid',['free_grid',['../life_8c.html#a3ec4cb07a71f6767ac69f6dc36e18190',1,'free_grid(unsigned char **grid, int width):&#160;life.c'],['../life_8h.html#a3ec4cb07a71f6767ac69f6dc36e18190',1,'free_grid(unsigned char **grid, int width):&#160;life.c']]]
];
