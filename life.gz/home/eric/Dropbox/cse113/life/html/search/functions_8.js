var searchData=
[
  ['sdl_5frender_5flife',['sdl_render_life',['../sdl_8h.html#afec672c5d4f9b0381339bd3229f28889',1,'sdl.h']]],
  ['sdl_5ftest',['sdl_test',['../sdl_8h.html#ada6b3150b36edb0a418e47d340006ea4',1,'sdl.h']]],
  ['set_5fcell',['set_cell',['../life_8c.html#a1245578ce0873814053cc555e23fee63',1,'set_cell(unsigned char **life_grid, int width, int height, struct point_t cell, int value):&#160;life.c'],['../life_8h.html#a1245578ce0873814053cc555e23fee63',1,'set_cell(unsigned char **life_grid, int width, int height, struct point_t cell, int value):&#160;life.c']]]
];
