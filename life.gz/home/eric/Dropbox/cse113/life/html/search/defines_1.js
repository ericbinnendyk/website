var searchData=
[
  ['hedge',['HEDGE',['../life_8h.html#a9917cd5021991253e0108418e23f9637',1,'life.h']]]
];
