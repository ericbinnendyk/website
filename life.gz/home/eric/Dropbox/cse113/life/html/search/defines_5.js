var searchData=
[
  ['torus',['TORUS',['../life_8h.html#aa20dd2cef76114dea8976ed59c86908c',1,'life.h']]]
];
