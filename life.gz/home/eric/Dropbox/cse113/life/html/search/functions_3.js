var searchData=
[
  ['init_5fmatrix',['init_matrix',['../life_8c.html#a76ac27b69b22601b4533c60ceefbdc42',1,'init_matrix(int height, int width):&#160;life.c'],['../life_8h.html#a76ac27b69b22601b4533c60ceefbdc42',1,'init_matrix(int height, int width):&#160;life.c']]],
  ['init_5fpoint_5farray',['init_point_array',['../gl_8c.html#a65e9cf599bedd60eb65539bfae159942',1,'gl.c']]],
  ['init_5fsdl_5finfo',['init_sdl_info',['../sdl_8h.html#a1094292af49bb6c4abf089ab73a79bb9',1,'sdl.h']]],
  ['init_5fstr_5farray',['init_str_array',['../gl_8c.html#ab8cf41ab3f39e209400719c62cb28817',1,'gl.c']]]
];
